import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Box,
  Card,
  CardContent,
  Button,
  FormControl,
  FormControlLabel,
  Radio,
  RadioGroup,
  Alert,
  Snackbar,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  LinearProgress,
  Divider,
  Grid
} from '@mui/material';
import { useParams, useNavigate } from 'react-router-dom';
import { getGlobalCourses, saveGlobalCourses } from '../../utils/stateManager';

const QuizAttempt = () => {
  const { courseId, quizId } = useParams();
  const navigate = useNavigate();
  const [quiz, setQuiz] = useState(null);
  const [answers, setAnswers] = useState({});
  const [showResults, setShowResults] = useState(false);
  const [score, setScore] = useState(0);
  const [pointsEarned, setPointsEarned] = useState(0);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success'
  });
  const [previousAttempts, setPreviousAttempts] = useState([]);
  const [attemptDate, setAttemptDate] = useState(null);

  useEffect(() => {
    loadQuiz();
  }, [courseId, quizId]);

  const loadQuiz = () => {
    try {
      const courses = getGlobalCourses();
      const course = courses.find(c => c.id === parseInt(courseId));
      
      if (course && course.quizzes) {
        const foundQuiz = course.quizzes.find(q => q.id === parseInt(quizId));
        if (foundQuiz) {
          setQuiz(foundQuiz);
          // Initialize answers
          const initialAnswers = {};
          foundQuiz.questions.forEach((_, index) => {
            initialAnswers[index] = -1;
          });
          setAnswers(initialAnswers);

          // Load previous attempts
          if (course.quizAttempts) {
            const attempts = course.quizAttempts.filter(a => a.quizId === parseInt(quizId));
            setPreviousAttempts(attempts.sort((a, b) => b.score - a.score));
          }
        }
      }
    } catch (error) {
      console.error('Error loading quiz:', error);
      setSnackbar({
        open: true,
        message: 'Error loading quiz. Please try again.',
        severity: 'error'
      });
    }
  };

  const handleAnswerChange = (questionIndex, value) => {
    setAnswers({
      ...answers,
      [questionIndex]: parseInt(value)
    });
  };

  const calculateResults = () => {
    let correctPoints = 0;
    let totalPoints = 0;

    quiz.questions.forEach((question, index) => {
      totalPoints += question.points;
      if (answers[index] === question.correctAnswer) {
        correctPoints += question.points;
      }
    });

    const percentageScore = Math.round((correctPoints / totalPoints) * 100);
    setPointsEarned(correctPoints);
    setScore(percentageScore);
    return { percentageScore, correctPoints, totalPoints };
  };

  const saveQuizAttempt = (results) => {
    try {
      const courses = getGlobalCourses();
      const courseIndex = courses.findIndex(c => c.id === parseInt(courseId));
      
      if (courseIndex === -1) return;

      if (!courses[courseIndex].quizAttempts) {
        courses[courseIndex].quizAttempts = [];
      }

      const attemptData = {
        id: Date.now(),
        quizId: parseInt(quizId),
        answers,
        score: results.percentageScore,
        pointsEarned: results.correctPoints,
        totalPoints: results.totalPoints,
        passed: results.percentageScore >= quiz.passingScore,
        attemptedAt: new Date().toISOString()
      };

      courses[courseIndex].quizAttempts.push(attemptData);
      saveGlobalCourses(courses);
      setPreviousAttempts([attemptData, ...previousAttempts]);
    } catch (error) {
      console.error('Error saving quiz attempt:', error);
    }
  };

  const handleSubmit = () => {
    // Check if all questions are answered
    const unanswered = Object.values(answers).some(answer => answer === -1);
    if (unanswered) {
      setSnackbar({
        open: true,
        message: 'Please answer all questions before submitting',
        severity: 'error'
      });
      return;
    }
    // Directly submit the quiz
    confirmSubmit();
  };

  const confirmSubmit = () => {
    const results = calculateResults();
    saveQuizAttempt(results);
    setShowResults(true);
    setAttemptDate(new Date());
  };

  const handleRetake = () => {
    setShowResults(false);
    loadQuiz();
  };

  if (!quiz) {
    return (
      <Container maxWidth="md" sx={{ mt: 4, mb: 4 }}>
        <Alert severity="error">Quiz not found</Alert>
      </Container>
    );
  }

  return (
    <Container maxWidth="md" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          {quiz.title}
        </Typography>
        <Typography variant="subtitle1" color="textSecondary" gutterBottom>
          Total Questions: {quiz.questions.length}
        </Typography>
      </Box>
      {!showResults ? (
        <Card>
          <CardContent>
            {quiz.questions.map((question, qIdx) => (
              <Box key={qIdx} sx={{ mb: 3 }}>
                <Typography variant="h6" sx={{ mb: 1 }}>
                  {qIdx + 1}. {question.question}
                </Typography>
                <FormControl component="fieldset">
                  <RadioGroup
                    value={answers[qIdx] === -1 ? '' : answers[qIdx].toString()}
                    onChange={(e) => handleAnswerChange(qIdx, e.target.value)}
                  >
                    {question.options.map((option, oIdx) => (
                      <FormControlLabel
                        key={oIdx}
                        value={oIdx.toString()}
                        control={<Radio color="primary" />}
                        label={option}
                      />
                    ))}
                  </RadioGroup>
                </FormControl>
              </Box>
            ))}
            <Button variant="contained" color="primary" onClick={handleSubmit}>
              Submit Quiz
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent>
            <Typography variant="h4" gutterBottom align="center">
              Quiz Results
            </Typography>
            <Typography variant="h5" align="center" color="primary" gutterBottom>
              Score: {score} / {quiz.totalPoints || quiz.totalMarks || 0}
            </Typography>
            <Typography variant="body1" align="center" paragraph>
              Percentage: {quiz.totalPoints || quiz.totalMarks ? ((score / (quiz.totalPoints || quiz.totalMarks)) * 100).toFixed(2) : 0}%
            </Typography>
            <Typography variant="body2" align="center" paragraph>
              Attempted on: {attemptDate ? attemptDate.toLocaleString() : new Date().toLocaleString()}
            </Typography>
            <Box sx={{ display: 'flex', justifyContent: 'center', mt: 3 }}>
              <Button
                variant="contained"
                onClick={() => navigate('/dashboard')}
              >
                Return to Dashboard
              </Button>
            </Box>
          </CardContent>
        </Card>
      )}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={3000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert severity={snackbar.severity}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default QuizAttempt; 