import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Box,
  Card,
  CardContent,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  useTheme,
} from '@mui/material';
import { useParams } from 'react-router-dom';
import { getGlobalCourses } from '../../utils/stateManager';

const QuizResults = () => {
  const { courseId, quizId } = useParams();
  const theme = useTheme();
  const [quiz, setQuiz] = useState(null);
  const [course, setCourse] = useState(null);

  useEffect(() => {
    const courses = getGlobalCourses();
    const foundCourse = courses.find(c => c.id === parseInt(courseId));
    if (foundCourse) {
      setCourse(foundCourse);
      const foundQuiz = foundCourse.quizzes?.find(q => q.id === parseInt(quizId));
      if (foundQuiz) {
        setQuiz(foundQuiz);
      }
    }
  }, [courseId, quizId]);

  if (!quiz || !course) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h6" color="error">Quiz not found</Typography>
      </Container>
    );
  }

  // Gather all attempts for this quiz from course.quizAttempts
  const attempts = (course.quizAttempts || []).filter(a => a.quizId === quiz.id);

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          Quiz Results
        </Typography>
        <Typography variant="subtitle1" sx={{ mb: 3 }}>
          {course.title} - {quiz.title}
        </Typography>
      </Box>
      <Card>
        <CardContent>
          <TableContainer component={Paper}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Student</TableCell>
                  <TableCell>Score</TableCell>
                  <TableCell>Date & Time</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {attempts.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={3} align="center">
                      No attempts for this quiz yet.
                    </TableCell>
                  </TableRow>
                ) : (
                  attempts.map((attempt, index) => (
                    <TableRow key={attempt.id || index}>
                      <TableCell>{attempt.studentName || attempt.studentId || 'Unknown'}</TableCell>
                      <TableCell>{attempt.score}%</TableCell>
                      <TableCell>{new Date(attempt.attemptedAt).toLocaleString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>
    </Container>
  );
};

export default QuizResults; 