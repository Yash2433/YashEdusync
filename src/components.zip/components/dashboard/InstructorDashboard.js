import React, { useState, useEffect } from 'react';
import {
  Box,
  Container,
  Grid,
  Card,
  CardContent,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  IconButton,
  Snackbar,
  Alert,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  Paper
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import { useNavigate } from 'react-router-dom';
import { getGlobalCourses, saveGlobalCourses } from '../../utils/stateManager';
import SchoolIcon from '@mui/icons-material/School';
import PeopleIcon from '@mui/icons-material/People';
import AssignmentIcon from '@mui/icons-material/Assignment';

const InstructorDashboard = () => {
  const navigate = useNavigate();
  const [courses, setCourses] = useState([]);
  const [open, setOpen] = useState(false);
  const [courseForm, setCourseForm] = useState({
    title: '',
    description: '',
    imageUrl: ''
  });
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success'
  });
  const [quizResults, setQuizResults] = useState([]);
  const [showResults, setShowResults] = useState(false);
  const [resultsQuizTitle, setResultsQuizTitle] = useState('');

  // Always load latest courses from localStorage on mount and when refresh is triggered
  const loadCourses = () => {
    setCourses(getGlobalCourses());
  };

  useEffect(() => {
    loadCourses();
  }, []);

  useEffect(() => {
    // Listen for localStorage changes (from other tabs/windows)
    const handleStorage = (event) => {
      if (event.key && event.key.startsWith('enrollments_')) {
        loadCourses();
      }
      if (event.key === 'courses') {
        loadCourses();
      }
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setCourseForm({ title: '', description: '', imageUrl: '' });
  };

  const handleSnackbarClose = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  const validateForm = () => {
    if (!courseForm.title.trim()) {
      setSnackbar({
        open: true,
        message: 'Please enter a course title',
        severity: 'error'
      });
      return false;
    }
    if (!courseForm.description.trim()) {
      setSnackbar({
        open: true,
        message: 'Please enter a course description',
        severity: 'error'
      });
      return false;
    }
    return true;
  };

  const handleAddCourse = () => {
    if (!validateForm()) return;

    const allCourses = getGlobalCourses() || [];
    const newCourse = {
      id: Date.now(),
      title: courseForm.title.trim(),
      description: courseForm.description.trim(),
      imageUrl: courseForm.imageUrl.trim() || `https://via.placeholder.com/300x200?text=${encodeURIComponent(courseForm.title.trim())}`,
      contents: [],
      quizzes: [],
      createdAt: new Date().toISOString()
    };

    allCourses.push(newCourse);
    saveGlobalCourses(allCourses);
    setCourses(allCourses);

    setSnackbar({
      open: true,
      message: 'Course added successfully!',
      severity: 'success'
    });
    handleClose();
  };

  const handleDeleteCourse = (courseId) => {
    const updatedCourses = courses.filter(course => course.id !== courseId);
    saveGlobalCourses(updatedCourses);
    setCourses(updatedCourses);

    setSnackbar({
      open: true,
      message: 'Course deleted successfully',
      severity: 'success'
    });
  };

  const handleEditCourse = (courseId) => {
    navigate(`/course/${courseId}`);
  };

  const handleManageContent = (courseId) => {
    navigate(`/instructor/course/${courseId}/content`);
  };

  const handleAddQuiz = (courseId) => {
    navigate(`/course/${courseId}/quiz/create`);
  };

  const handleViewQuizResults = (quiz, course) => {
    // Gather all quiz attempts from all users
    const allAttempts = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key.startsWith('quiz_attempts_')) {
        const userAttempts = JSON.parse(localStorage.getItem(key)) || [];
        allAttempts.push(...userAttempts);
      }
    }
    // Filter for this quiz
    const attemptsForQuiz = allAttempts.filter(a => a.quizId === quiz.id);
    setQuizResults(attemptsForQuiz);
    setResultsQuizTitle(`${quiz.title} (${course.title})`);
    setShowResults(true);
  };

  // Helper functions for stats
  const getTotalStudents = () => {
    const uniqueStudents = new Set();
    courses.forEach(course => {
      course.enrolledStudents?.forEach(studentId => uniqueStudents.add(studentId));
    });
    return uniqueStudents.size;
  };

  const getAverageProgress = () => {
    let totalProgress = 0;
    let totalCourses = 0;
    courses.forEach(course => {
      if (course.progress) {
        Object.values(course.progress).forEach(progress => {
          totalProgress += progress;
          totalCourses++;
        });
      }
    });
    return totalCourses > 0 ? Math.round(totalProgress / totalCourses) : 0;
  };

  const getQuizAttempts = (course) => {
    let attempts = 0;
    course.quizzes?.forEach(quiz => {
      attempts += quiz.attempts?.length || 0;
    });
    return attempts;
  };

  const user = JSON.parse(localStorage.getItem('user'));

  return (
    <Container maxWidth="lg" sx={{ mt: 6, mb: 6 }}>
      <Box sx={{ mb: 5 }}>
        <Typography variant="h4" sx={{ fontWeight: 700, color: 'primary.main', letterSpacing: '-0.5px', mb: 1 }}>
          Instructor Dashboard
        </Typography>
        <Typography variant="subtitle1" sx={{ color: 'text.secondary', mb: 4 }}>
          Manage your courses and track student progress
        </Typography>
      </Box>
      <Grid container spacing={4}>
        {/* Stats Cards */}
        <Grid item xs={12} md={4}>
          <Card sx={{ p: 3 }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <SchoolIcon color="primary" sx={{ mr: 1 }} />
                <Typography variant="h6" color="primary">
                  Total Courses
                </Typography>
              </Box>
              <Typography variant="h3" sx={{ mb: 1, fontWeight: 700 }}>
                {courses.length}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Active courses in your portfolio
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card sx={{ p: 3 }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <PeopleIcon color="primary" sx={{ mr: 1 }} />
                <Typography variant="h6" color="primary">
                  Total Students
                </Typography>
              </Box>
              <Typography variant="h3" sx={{ mb: 1, fontWeight: 700 }}>
                {getTotalStudents()}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Enrolled students across all courses
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card sx={{ p: 3 }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <AssignmentIcon color="primary" sx={{ mr: 1 }} />
                <Typography variant="h6" color="primary">
                  Average Progress
                </Typography>
              </Box>
              <Typography variant="h3" sx={{ mb: 1, fontWeight: 700 }}>
                {getAverageProgress()}%
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Average student progress across courses
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        {/* Course Management */}
        <Grid item xs={12}>
          <Card sx={{ p: 4 }}>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
                <Typography variant="h5" color="primary" sx={{ fontWeight: 700 }}>
                  Course Management
                </Typography>
                <Button
                  variant="contained"
                  color="primary"
                  sx={{ borderRadius: 3, fontWeight: 600, px: 4, py: 1.5, boxShadow: '0 2px 8px 0 rgba(91,109,205,0.10)' }}
                  onClick={() => navigate('/courses/manage')}
                >
                  Manage Courses
                </Button>
              </Box>
              <TableContainer component={Paper} sx={{ borderRadius: 3, boxShadow: '0 2px 8px 0 rgba(91,109,205,0.06)' }}>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Course Title</TableCell>
                      <TableCell>Enrolled Students</TableCell>
                      <TableCell>Quiz Attempts</TableCell>
                      <TableCell>Actions</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {courses.map((course) => (
                      <TableRow key={course.id} sx={{ '&:hover': { background: '#F7F9FB' } }}>
                        <TableCell>
                          <Typography variant="subtitle1" sx={{ fontWeight: 600, color: 'text.primary' }}>
                            {course.title}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip
                            label={`${course.enrolledStudents ? course.enrolledStudents.length : 0} students`}
                            color="primary"
                            title={course.enrolledStudents && course.enrolledStudents.length > 0 ? course.enrolledStudents.map(s => s.name).join(', ') : ''}
                            sx={{ fontWeight: 500, fontSize: 15 }}
                          />
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2" color="text.secondary">
                            {getQuizAttempts(course)} attempts
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Box sx={{ display: 'flex', gap: 1 }}>
                            <Button
                              variant="outlined"
                              size="small"
                              color="primary"
                              sx={{ borderRadius: 2, fontWeight: 600, px: 2, py: 0.5 }}
                              onClick={() => navigate(`/course/${course.id}/quiz/create`)}
                            >
                              Create Quiz
                            </Button>
                            <Button
                              variant="outlined"
                              size="small"
                              color="primary"
                              sx={{ borderRadius: 2, fontWeight: 600, px: 2, py: 0.5 }}
                              onClick={() => navigate(`/instructor/course/${course.id}/quiz/${course.quizzes && course.quizzes[0] ? course.quizzes[0].id : ''}/results`)}
                            >
                              Quiz Results
                            </Button>
                          </Box>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Add Course Dialog */}
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>Add New Course</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="Course Title"
            type="text"
            fullWidth
            variant="outlined"
            value={courseForm.title}
            onChange={(e) => setCourseForm({ ...courseForm, title: e.target.value })}
          />
          <TextField
            margin="dense"
            label="Course Description"
            type="text"
            fullWidth
            variant="outlined"
            multiline
            rows={4}
            value={courseForm.description}
            onChange={(e) => setCourseForm({ ...courseForm, description: e.target.value })}
          />
          <TextField
            margin="dense"
            label="Course Image URL (Optional)"
            type="text"
            fullWidth
            variant="outlined"
            value={courseForm.imageUrl}
            onChange={(e) => setCourseForm({ ...courseForm, imageUrl: e.target.value })}
            helperText="Leave blank for a default image"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button onClick={handleAddCourse} variant="contained" color="primary">
            Add Course
          </Button>
        </DialogActions>
      </Dialog>

      {/* Quiz Results Dialog */}
      <Dialog open={showResults} onClose={() => setShowResults(false)} maxWidth="md" fullWidth>
        <DialogTitle>Quiz Results - {resultsQuizTitle}</DialogTitle>
        <DialogContent>
          {quizResults.length === 0 ? (
            <Alert severity="info">No attempts for this quiz yet.</Alert>
          ) : (
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Student ID</TableCell>
                    <TableCell>Score</TableCell>
                    <TableCell>Date</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {quizResults.map(result => (
                    <TableRow key={result.studentId + result.timestamp}>
                      <TableCell>{result.studentName || result.studentId}</TableCell>
                      <TableCell>{result.score}%</TableCell>
                      <TableCell>{new Date(result.timestamp).toLocaleString()}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowResults(false)}>Close</Button>
        </DialogActions>
      </Dialog>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={3000}
        onClose={handleSnackbarClose}
      >
        <Alert severity={snackbar.severity}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default InstructorDashboard; 