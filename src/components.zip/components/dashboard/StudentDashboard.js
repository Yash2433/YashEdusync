import React, { useState, useEffect } from 'react';
import {
  Box,
  Container,
  Grid,
  Card,
  CardContent,
  CardMedia,
  Typography,
  Button,
  LinearProgress,
  Tabs,
  Tab,
  Divider,
  Alert,
  Snackbar,
  Chip
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import AssignmentIcon from '@mui/icons-material/Assignment';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import {
  getGlobalCourses,
  getUserEnrollments,
  getUserProgress,
  saveUserEnrollments,
  saveUserProgress,
  getQuizAttempts
} from '../../utils/stateManager';

const StudentDashboard = () => {
  const navigate = useNavigate();
  const [availableCourses, setAvailableCourses] = useState([]);
  const [enrolledCourses, setEnrolledCourses] = useState([]);
  const [activeTab, setActiveTab] = useState(0);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const user = JSON.parse(localStorage.getItem('user'));

  // Load courses and enrollment data
  const loadCourses = () => {
    const savedCourses = getGlobalCourses();
    const studentEnrollments = getUserEnrollments();
    const studentProgress = getUserProgress();
    const quizAttempts = getQuizAttempts();

    // Filter enrolled and available courses
    const enrolled = savedCourses.filter(course => 
      studentEnrollments.includes(course.id)
    ).map(course => {
      // Calculate content completion
      const totalContents = course.contents?.length || 0;
      const completedContents = course.contents?.filter(content => 
        localStorage.getItem(`content_${content.id}_completed`) === 'true'
      ).length || 0;
      
      const progress = totalContents > 0 ? Math.round((completedContents / totalContents) * 100) : 0;
      const allContentCompleted = totalContents > 0 && completedContents === totalContents;

      return {
        ...course,
        progress,
        allContentCompleted,
        quizAttempts: course.quizzes?.map(quiz => {
          const attempts = quizAttempts.filter(a => a.quizId === quiz.id);
          return {
            ...quiz,
            attempts: attempts,
            bestScore: attempts.length > 0 ? Math.max(...attempts.map(a => a.score)) : null
          };
        }) || []
      };
    });

    const available = savedCourses.filter(course => 
      !studentEnrollments.includes(course.id)
    );

    setEnrolledCourses(enrolled);
    setAvailableCourses(available);
  };

  useEffect(() => {
    loadCourses();
  }, []);

  const enrollInCourse = (courseId) => {
    const studentEnrollments = getUserEnrollments();
    if (!studentEnrollments.includes(courseId)) {
      const newEnrollments = [...studentEnrollments, courseId];
      saveUserEnrollments(newEnrollments);
      
      const courseToEnroll = availableCourses.find(c => c.id === courseId);
      setAvailableCourses(prev => prev.filter(c => c.id !== courseId));
      setEnrolledCourses(prev => [...prev, { ...courseToEnroll, progress: 0 }]);
      
      setSnackbar({ 
        open: true, 
        message: 'Successfully enrolled in the course!',
        severity: 'success'
      });

      loadCourses();
    }
  };

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  const renderCourseCard = (course, isEnrolled = false) => (
    <Grid item xs={12} sm={6} md={4} key={course.id}>
      <Card
        sx={{
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          borderRadius: 6,
          boxShadow: '0 8px 32px 0 rgba(106,17,203,0.15)',
          background: 'linear-gradient(135deg, rgba(255,255,255,0.85) 60%, #e0c3fc 100%)',
          backdropFilter: 'blur(8px)',
          transition: 'transform 0.3s, box-shadow 0.3s',
          '&:hover': {
            transform: 'translateY(-8px) scale(1.03)',
            boxShadow: '0 16px 48px 0 rgba(106,17,203,0.25)',
            background: 'linear-gradient(135deg, #e0c3fc 0%, #8ec5fc 100%)',
          },
        }}
      >
        <CardMedia
          component="img"
          height="160"
          image={course.imageUrl}
          alt={course.title}
          sx={{
            borderTopLeftRadius: 24,
            borderTopRightRadius: 24,
            objectFit: 'cover',
            boxShadow: '0 2px 12px rgba(106,17,203,0.10)',
          }}
        />
        <CardContent sx={{ flexGrow: 1 }}>
          <Typography gutterBottom variant="h5" component="h2" sx={{ fontWeight: 700, color: 'primary.main', letterSpacing: '-0.5px' }}>
            {course.title}
          </Typography>
          <Typography variant="body2" color="text.secondary" paragraph sx={{ fontWeight: 500 }}>
            {course.description}
          </Typography>
          {isEnrolled && (
            <>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <Box sx={{ width: '100%', mr: 1 }}>
                  <LinearProgress
                    variant="determinate"
                    value={course.progress}
                    sx={{
                      height: 10,
                      borderRadius: 5,
                      background: 'rgba(67,233,123,0.10)',
                      '& .MuiLinearProgress-bar': {
                        background: 'linear-gradient(90deg, #43e97b 0%, #38f9d7 100%)',
                        boxShadow: '0 2px 8px rgba(67,233,123,0.10)',
                      },
                    }}
                  />
                </Box>
                <Box sx={{ minWidth: 35 }}>
                  <Typography variant="body2" color="primary" sx={{ fontWeight: 700 }}>
                    {course.progress}%
                  </Typography>
                </Box>
              </Box>
              <Button
                variant="contained"
                color="primary"
                fullWidth
                onClick={() => navigate(`/course/${course.id}/content`)}
                sx={{ mb: 2, borderRadius: 12, fontWeight: 600, fontSize: 16, letterSpacing: '0.5px', boxShadow: '0 2px 8px rgba(67,233,123,0.10)' }}
              >
                {course.progress === 100 ? 'Review Course' : 'Continue Learning'}
              </Button>
              {course.progress === 100 && course.quizzes && course.quizzes.length > 0 && (
                <Button
                  variant="outlined"
                  color="secondary"
                  fullWidth
                  sx={{ mb: 2, mt: 1, borderRadius: 12, fontWeight: 600, fontSize: 16, letterSpacing: '0.5px', background: 'linear-gradient(90deg, #43e97b 0%, #38f9d7 100%)', color: '#fff', boxShadow: '0 2px 8px rgba(67,233,123,0.10)', '&:hover': { background: 'linear-gradient(90deg, #2575fc 0%, #6a11cb 100%)', color: '#fff' } }}
                  onClick={() => navigate(`/course/${course.id}/quiz/${course.quizzes[0].id}`)}
                >
                  Attempt Quiz
                </Button>
              )}
            </>
          )}
          {!isEnrolled && (
            <Button
              size="large"
              color="primary"
              fullWidth
              variant="contained"
              sx={{ mt: 2, borderRadius: 12, fontWeight: 600, fontSize: 16, letterSpacing: '0.5px', background: 'linear-gradient(90deg, #43e97b 0%, #38f9d7 100%)', color: '#fff', boxShadow: '0 2px 8px rgba(67,233,123,0.10)', '&:hover': { background: 'linear-gradient(90deg, #2575fc 0%, #6a11cb 100%)', color: '#fff' } }}
              onClick={() => enrollInCourse(course.id)}
            >
              Enroll Now
            </Button>
          )}
        </CardContent>
      </Card>
    </Grid>
  );

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" gutterBottom>
        Welcome, {user?.name || 'Student'}
      </Typography>

      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
        <Tabs value={activeTab} onChange={handleTabChange}>
          <Tab label="My Courses" />
          <Tab label="Available Courses" />
        </Tabs>
      </Box>

      {activeTab === 0 && (
        <>
          {enrolledCourses.length === 0 ? (
            <Alert severity="info" sx={{ mt: 2 }}>
              You haven't enrolled in any courses yet. Check out the Available Courses tab to get started!
            </Alert>
          ) : (
            <Grid container spacing={3}>
              {enrolledCourses.map(course => renderCourseCard(course, true))}
            </Grid>
          )}
        </>
      )}

      {activeTab === 1 && (
        <>
          {availableCourses.length === 0 ? (
            <Alert severity="info" sx={{ mt: 2 }}>
              No courses available at the moment. Check back later!
            </Alert>
          ) : (
            <Grid container spacing={3}>
              {availableCourses.map(course => renderCourseCard(course))}
            </Grid>
          )}
        </>
      )}

      <Snackbar
        open={snackbar.open}
        autoHideDuration={3000}
        onClose={handleCloseSnackbar}
      >
        <Alert onClose={handleCloseSnackbar} severity={snackbar.severity}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default StudentDashboard; 