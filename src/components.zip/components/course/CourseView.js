import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Box,
  Card,
  CardContent,
  Button,
  Alert,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Grid,
  LinearProgress
} from '@mui/material';
import { useParams, useNavigate } from 'react-router-dom';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import AssignmentIcon from '@mui/icons-material/Assignment';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { getGlobalCourses } from '../../utils/stateManager';

const CourseView = () => {
  const { courseId } = useParams();
  const navigate = useNavigate();
  const [course, setCourse] = useState(null);
  const [quizDialog, setQuizDialog] = useState(false);
  const [selectedQuiz, setSelectedQuiz] = useState(null);
  const [courseProgress, setCourseProgress] = useState(0);
  const [quizAttempts, setQuizAttempts] = useState([]);

  useEffect(() => {
    loadCourse();
  }, [courseId]);

  const loadCourse = () => {
    const courses = getGlobalCourses();
    const foundCourse = courses.find(c => c.id === parseInt(courseId));
    if (foundCourse) {
      setCourse(foundCourse);
      
      // Calculate course progress
      if (foundCourse.contents && foundCourse.contents.length > 0) {
        const completedContents = foundCourse.contents.filter(content => 
          localStorage.getItem(`content_${content.id}_completed`) === 'true'
        ).length;
        const progress = Math.round((completedContents / foundCourse.contents.length) * 100);
        setCourseProgress(progress);
      }

      // Load quiz attempts
      if (foundCourse.quizAttempts) {
        setQuizAttempts(foundCourse.quizAttempts);
      }
    }
  };

  const handleContentClick = (content) => {
    navigate(`/course/${courseId}/content/${content.id}`);
  };

  const handleQuizClick = (quiz) => {
    setSelectedQuiz(quiz);
    setQuizDialog(true);
  };

  const startQuiz = () => {
    setQuizDialog(false);
    navigate(`/course/${courseId}/quiz/${selectedQuiz.id}`);
  };

  const isContentCompleted = (contentId) => {
    return localStorage.getItem(`content_${contentId}_completed`) === 'true';
  };

  const getQuizAttempts = (quizId) => {
    return quizAttempts.filter(attempt => attempt.quizId === quizId);
  };

  const getBestScore = (quizId) => {
    const attempts = getQuizAttempts(quizId);
    if (attempts.length === 0) return null;
    return Math.max(...attempts.map(attempt => attempt.score));
  };

  if (!course) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Alert severity="error">Course not found</Alert>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" gutterBottom>
        {course?.title}
      </Typography>
      <Typography variant="subtitle1" sx={{ mb: 3 }}>
        {course?.description}
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          <Card>
            <CardContent>
              <Typography variant="h5" sx={{ mb: 2 }}>Course Content</Typography>
              <List>
                {course?.contents?.map((content, idx) => (
                  <ListItem key={content.id} divider>
                    <ListItemText
                      primary={<Typography>{idx + 1}. {content.title}</Typography>}
                      secondary={<Typography variant="body2" color="textSecondary">{content.type === 'video' ? 'Video' : 'Link'}</Typography>}
                    />
                    <ListItemSecondaryAction>
                      <IconButton edge="end" color="primary" onClick={() => handleContentClick(content)}>
                        <PlayArrowIcon />
                      </IconButton>
                    </ListItemSecondaryAction>
                  </ListItem>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Typography variant="h6" sx={{ mb: 2 }}>Progress</Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <LinearProgress variant="determinate" value={courseProgress} sx={{ flex: 1, height: 10, mr: 2 }} />
                <Typography variant="body2">{courseProgress}%</Typography>
              </Box>
              {course?.quizzes && course?.quizzes.length > 0 && courseProgress === 100 && (
                <Button
                  variant="contained"
                  color="primary"
                  fullWidth
                  sx={{ mt: 2 }}
                  onClick={() => { setSelectedQuiz(course.quizzes[0]); setQuizDialog(true); }}
                >
                  Attempt Quiz
                </Button>
              )}
            </CardContent>
          </Card>
        </Grid>
      </Grid>
      <Dialog open={quizDialog} onClose={() => setQuizDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Quiz</DialogTitle>
        <DialogContent>
          <Typography variant="h6" sx={{ mb: 2 }}>{selectedQuiz?.title}</Typography>
          <Typography variant="body2" color="textSecondary">{selectedQuiz?.description}</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setQuizDialog(false)}>Close</Button>
          <Button variant="contained" color="primary" onClick={() => navigate(`/course/${course.id}/quiz/${selectedQuiz.id}`)}>Start Quiz</Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default CourseView; 