import React from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  CardMedia,
  Alert
} from '@mui/material';

const VideoPlayer = ({ content }) => {
  const isYouTubeUrl = (url) => {
    return url.includes('youtube.com') || url.includes('youtu.be');
  };

  const getYouTubeVideoId = (url) => {
    if (url.includes('youtu.be')) {
      return url.split('/').pop();
    }
    return new URLSearchParams(new URL(url).search).get('v');
  };

  const renderVideo = () => {
    if (!content.url) {
      return <Alert severity="error">No video URL provided</Alert>;
    }

    if (isYouTubeUrl(content.url)) {
      const videoId = getYouTubeVideoId(content.url);
      return (
        <iframe
          width="100%"
          height="500"
          src={`https://www.youtube.com/embed/${videoId}`}
          frameBorder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          title={content.title}
        />
      );
    }

    return (
      <video
        controls
        width="100%"
        src={content.url}
        style={{ maxHeight: '500px' }}
      >
        Your browser does not support the video tag.
      </video>
    );
  };

  return (
    <Card>
      <CardMedia
        component="img"
        height="200"
        image={content.thumbnailUrl}
        alt={content.title}
        sx={{ display: { xs: 'block', md: 'none' } }}
      />
      {renderVideo()}
      <CardContent>
        <Typography variant="h5" gutterBottom>
          {content.title}
        </Typography>
        {content.description && (
          <Typography variant="body1" color="text.secondary">
            {content.description}
          </Typography>
        )}
        {content.duration && (
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
            Duration: {content.duration}
          </Typography>
        )}
      </CardContent>
    </Card>
  );
};

export default VideoPlayer; 