import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Box,
  Card,
  CardContent,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Snackbar,
  Alert,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
  Chip
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { getGlobalCourses, saveGlobalCourses } from '../../utils/stateManager';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import AddIcon from '@mui/icons-material/Add';

const CourseManagement = () => {
  const navigate = useNavigate();
  const [courses, setCourses] = useState([]);
  const [open, setOpen] = useState(false);
  const [editingCourse, setEditingCourse] = useState(null);
  const [courseForm, setCourseForm] = useState({
    title: '',
    description: '',
    contents: [],
    contentType: 'url',
    contentUrl: '',
    contentFile: null,
    contentTitle: ''
  });

  // Helper function to safely get content length
  const getContentLength = (contents) => {
    return contents ? contents.length : 0;
  };

  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success'
  });

  useEffect(() => {
    loadCourses();
  }, []);

  const loadCourses = () => {
    const allCourses = getGlobalCourses() || [];
    setCourses(allCourses);
  };

  const handleClickOpen = () => {
    setOpen(true);
    setEditingCourse(null);
    setCourseForm({
      title: '',
      description: '',
      contents: [],
      videoUrl: '',
      videoFile: null
    });
  };

  const handleClose = () => {
    setOpen(false);
    setEditingCourse(null);
    setCourseForm({
      title: '',
      description: '',
      videoUrl: '',
      videoFile: null
    });
  };

  const handleSnackbarClose = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  const validateForm = () => {
    // Check if we're editing an existing course
    const isEditing = !!editingCourse;
    
    // Get values with fallbacks
    const title = isEditing ? courseForm.title || editingCourse.title : courseForm.title;
    const description = isEditing ? courseForm.description || editingCourse.description : courseForm.description;
    
    // Validate required fields
    if (!title?.trim()) {
      setSnackbar({
        open: true,
        message: 'Please enter a course title',
        severity: 'error'
      });
      return false;
    }
    if (!description?.trim()) {
      setSnackbar({
        open: true,
        message: 'Please enter a course description',
        severity: 'error'
      });
      return false;
    }

    // Validate content if we're adding new content
    if (isEditing && courseForm.contentType) {
      if (!courseForm.contentTitle?.trim()) {
        setSnackbar({
          open: true,
          message: 'Please enter a content title',
          severity: 'error'
        });
        return false;
      }

      if (courseForm.contentType === 'url' && !courseForm.contentUrl?.trim()) {
        setSnackbar({
          open: true,
          message: 'Please enter a video URL',
          severity: 'error'
        });
        return false;
      }

      if (courseForm.contentType === 'file' && !courseForm.contentFile) {
        setSnackbar({
          open: true,
          message: 'Please upload a video file',
          severity: 'error'
        });
        return false;
      }
      return false;
    }
    return true;
  };

  const handleAddCourse = () => {
    if (!validateForm()) return;

    const allCourses = getGlobalCourses() || [];
    const newCourse = {
      id: Date.now(),
      title: courseForm.title.trim(),
      description: courseForm.description.trim(),
      contents: courseForm.contents,
      quizzes: [],
      createdAt: new Date().toISOString()
    };

    allCourses.push(newCourse);
    saveGlobalCourses(allCourses);
    setCourses(allCourses);

    setSnackbar({
      open: true,
      message: 'Course added successfully!',
      severity: 'success'
    });
    handleClose();
  };

  const handleEditCourse = (course) => {
    setEditingCourse(course);
    setCourseForm({
      title: course.title,
      description: course.description,
      contents: course.contents || []
    });
    setOpen(true);
  };

  const handleUpdateCourse = () => {
    if (!validateForm()) return;

    const allCourses = getGlobalCourses() || [];
    const courseIndex = allCourses.findIndex(c => c.id === editingCourse.id);
    
    if (courseIndex !== -1) {
      const updatedCourse = {
        ...allCourses[courseIndex],
        title: courseForm.title?.trim() || allCourses[courseIndex].title,
        description: courseForm.description?.trim() || allCourses[courseIndex].description,
        contents: courseForm.contents || allCourses[courseIndex].contents
      };

      allCourses[courseIndex] = updatedCourse;
      saveGlobalCourses(allCourses);
      setCourses(allCourses);

      setSnackbar({
        open: true,
        message: 'Course updated successfully!',
        severity: 'success'
      });
      handleClose();
    }
  };

  const handleDeleteCourse = (courseId) => {
    const updatedCourses = courses.filter(course => course.id !== courseId);
    saveGlobalCourses(updatedCourses);
    setCourses(updatedCourses);

    setSnackbar({
      open: true,
      message: 'Course deleted successfully',
      severity: 'success'
    });
  };

  const handleManageContent = (courseId) => {
    navigate(`/instructor/course/${courseId}/content`);
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 6, mb: 6 }}>
      <Box sx={{ mb: 5 }}>
        <Typography variant="h4" sx={{ fontWeight: 700, color: 'primary.main', letterSpacing: '-0.5px', mb: 1 }}>
          Course Management
        </Typography>
        <Typography variant="subtitle1" sx={{ color: 'text.secondary', mb: 4 }}>
          Manage your courses and their content
        </Typography>
      </Box>
      <Card sx={{ mb: 5, p: 4 }}>
        <CardContent>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
            <Typography variant="h5" sx={{ fontWeight: 700, color: 'primary.main' }}>
              Your Courses
            </Typography>
            <Button
              variant="contained"
              onClick={handleClickOpen}
              startIcon={<AddIcon />}
              sx={{ borderRadius: 3, fontWeight: 600, px: 4, py: 1.5, boxShadow: '0 2px 8px 0 rgba(91,109,205,0.10)' }}
            >
              Add New Course
            </Button>
          </Box>
          <TableContainer component={Paper} sx={{ borderRadius: 3, boxShadow: '0 2px 8px 0 rgba(91,109,205,0.06)' }}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 700, color: 'primary.main' }}>Course Title</TableCell>
                  <TableCell sx={{ fontWeight: 700, color: 'primary.main' }}>Description</TableCell>
                  <TableCell sx={{ fontWeight: 700, color: 'primary.main' }}>Content Items</TableCell>
                  <TableCell sx={{ fontWeight: 700, color: 'primary.main' }}>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {courses.map((course) => (
                  <TableRow
                    key={course.id}
                    sx={{ '&:hover': { background: '#F7F9FB' } }}
                  >
                    <TableCell>
                      <Typography variant="subtitle1" sx={{ fontWeight: 600, color: 'text.primary' }}>
                        {course.title}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" color="text.secondary">
                        {course.description}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" color="text.secondary">
                        {course.contents?.length || 0} items
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Box sx={{ display: 'flex', gap: 1 }}>
                        <IconButton onClick={() => handleEditCourse(course)} color="primary" sx={{ borderRadius: 2 }}>
                          <EditIcon />
                        </IconButton>
                        <IconButton onClick={() => handleDeleteCourse(course.id)} color="error" sx={{ borderRadius: 2 }}>
                          <DeleteIcon />
                        </IconButton>
                      </Box>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>

      {/* Add/Edit Course Dialog */}
      <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth sx={{ borderRadius: 3 }}>
        <DialogTitle>
          {editingCourse ? 'Edit Course' : 'Add New Course'}
        </DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="Course Title"
            type="text"
            fullWidth
            variant="outlined"
            value={courseForm.title}
            onChange={(e) => setCourseForm({ ...courseForm, title: e.target.value })}
            sx={{ mb: 2 }}
          />
          <TextField
            margin="dense"
            label="Course Description"
            type="text"
            fullWidth
            variant="outlined"
            multiline
            rows={4}
            value={courseForm.description}
            onChange={(e) => setCourseForm({ ...courseForm, description: e.target.value })}
            sx={{ mb: 2 }}
          />
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
              <FormControl fullWidth>
                <InputLabel>Type</InputLabel>
                <Select
                  value={courseForm.contentType || 'url'}
                  onChange={(e) => setCourseForm({ ...courseForm, contentType: e.target.value })}
                  label="Type"
                  sx={{ mb: 2 }}
                >
                  <MenuItem value="url">Video URL</MenuItem>
                  <MenuItem value="file">Upload Video</MenuItem>
                </Select>
              </FormControl>

              {courseForm.contentType === 'url' ? (
                <TextField
                  fullWidth
                  label="Video URL"
                  value={courseForm.contentUrl || ''}
                  onChange={(e) => setCourseForm({ ...courseForm, contentUrl: e.target.value })}
                  helperText="Enter YouTube or Vimeo video URL"
                />
              ) : (
                <Button
                  variant="outlined"
                  component="label"
                  fullWidth
                  sx={{ mt: 2 }}
                >
                  Upload Video File
                  <input
                    type="file"
                    accept="video/*"
                    hidden
                    onChange={(e) => setCourseForm({ ...courseForm, contentFile: e.target.files[0] })}
                  />
                </Button>
              )}

              <TextField
                fullWidth
                label="Content Title"
                value={courseForm.contentTitle || ''}
                onChange={(e) => setCourseForm({ ...courseForm, contentTitle: e.target.value })}
                sx={{ mt: 2 }}
              />

              <Button
                variant="contained"
                onClick={() => {
                  if (!courseForm.contentTitle?.trim()) {
                    setSnackbar({
                      open: true,
                      message: 'Please enter a content title',
                      severity: 'error'
                    });
                    return;
                  }

                  if (courseForm.contentType === 'url' && !courseForm.contentUrl?.trim()) {
                    setSnackbar({
                      open: true,
                      message: 'Please enter a video URL',
                      severity: 'error'
                    });
                    return;
                  }

                  if (courseForm.contentType === 'file' && !courseForm.contentFile) {
                    setSnackbar({
                      open: true,
                      message: 'Please upload a video file',
                      severity: 'error'
                    });
                    return;
                  }

                  // Create new content item
                  const newContent = {
                    id: Date.now(),
                    type: courseForm.contentType,
                    title: courseForm.contentTitle.trim(),
                    url: courseForm.contentType === 'url' ? courseForm.contentUrl.trim() : '',
                    file: courseForm.contentType === 'file' ? courseForm.contentFile : null
                  };

                  // Update form state
                  setCourseForm(prev => ({
                    ...prev,
                    contents: [...(prev.contents || []), newContent],
                    contentType: 'url',
                    contentUrl: '',
                    contentFile: null,
                    contentTitle: ''
                  }));

                  // Show success message
                  setSnackbar({
                    open: true,
                    message: 'Content added successfully',
                    severity: 'success'
                  });
                }}
                sx={{ mt: 2 }}
              >
                Add Content
              </Button>
            </Box>
          </Box>

          {/* Content List */}
          {courseForm.contents?.length > 0 && (
            <Box sx={{ mt: 2, p: 2, border: '1px solid #ccc', borderRadius: 2 }}>
              <Typography variant="subtitle2" sx={{ mb: 1 }}>
                Added Contents:
              </Typography>
              {courseForm.contents.map((content, index) => (
                <Box key={content.id} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                  <Box sx={{ display: 'flex', gap: 1 }}>
                    <Typography variant="body2" sx={{ fontWeight: 600 }}>
                      {content.title}
                    </Typography>
                    <Chip
                      label={content.type === 'url' ? 'URL' : 'File'}
                      size="small"
                      sx={{ ml: 1 }}
                    />
                  </Box>
                  <IconButton
                    size="small"
                    color="error"
                    onClick={() => setCourseForm(prev => ({
                      ...prev,
                      contents: prev.contents.filter(c => c.id !== content.id)
                    }))}
                  >
                    <DeleteIcon />
                  </IconButton>
                </Box>
              ))}
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button 
            onClick={editingCourse ? handleUpdateCourse : handleAddCourse}
            variant="contained"
            color="primary"
          >
            {editingCourse ? 'Update Course' : 'Add Course'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar for notifications */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleSnackbarClose}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert onClose={handleSnackbarClose} severity={snackbar.severity}>
          {snackbar.message}
        </Alert>
      </Snackbar>


    </Container>
  );
};

export default CourseManagement; 